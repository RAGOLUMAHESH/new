package com.bharath.java8.lamdas.parameters;

@FunctionalInterface
public interface Sum {
	
	void add(int a,int  b);

}
