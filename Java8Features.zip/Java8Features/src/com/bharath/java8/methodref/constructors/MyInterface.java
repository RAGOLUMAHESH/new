package com.bharath.java8.methodref.constructors;

public interface MyInterface {
	
	MyClass get(String s);

}
