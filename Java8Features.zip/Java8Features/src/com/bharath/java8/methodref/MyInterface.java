package com.bharath.java8.methodref;

public interface MyInterface {
	
	public void myMethod(int i);

}
