package com.bharath.java8.defaultmethods;

public class B implements A,X{

	@Override
	public void m1() {
	
	}

	
}
