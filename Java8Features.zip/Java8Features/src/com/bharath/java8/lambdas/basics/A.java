package com.bharath.java8.lambdas.basics;


@FunctionalInterface
public interface A {
	
	void myMethod();
	
}
