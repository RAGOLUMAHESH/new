package snippet;

	class A {
	
	void add1(){}
	
	int add(){return 0;}
	
	}
